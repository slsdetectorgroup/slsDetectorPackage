# Permission to Relicense under MPLv2

This is a statement by Dhammika Pathirana
that grants permission to relicense its copyrights in the libzmq C++
library (ZeroMQ) under the Mozilla Public License v2 (MPLv2).

A portion of the commits made by the Github handle "dhammika", with
commit author "Dhammika Pathirana <dhammika@gmail.com>", are copyright of Dhammika Pathirana .
This document hereby grants the libzmq project team to relicense libzmq, 
including all past, present and future contributions of the author listed above.

Dhammika Pathirana
2019/08/12
