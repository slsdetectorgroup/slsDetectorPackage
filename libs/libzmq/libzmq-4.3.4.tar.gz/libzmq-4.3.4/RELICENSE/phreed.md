# Permission to Relicense under MPLv2

This is a statement by Fredrick Paul Eisele
that grants permission to relicense its copyrights in the libzmq C++
library (ZeroMQ) under the Mozilla Public License v2 (MPLv2).

A portion of the commits made by the Github handle phreed, with
commit author "Fred Eisele", are copyright of Fred Eisele .
This document hereby grants the libzmq project team to relicense
libzmq,
including all past, present and future contributions of the author
listed above.

Fredrick Paul Eisele
2020/01/03
